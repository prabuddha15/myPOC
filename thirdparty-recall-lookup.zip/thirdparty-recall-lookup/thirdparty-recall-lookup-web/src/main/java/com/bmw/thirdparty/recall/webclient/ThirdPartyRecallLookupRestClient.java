package com.bmw.thirdparty.recall.webclient;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.bmw.thirdparty.recall.service.HelloSessionBeanRemote;
import com.bmw.thirdparty.recall.service.impl.HelloSessionBean;

import java.util.HashSet;
import java.util.Set;

@ApplicationPath("/greeting")
public class ThirdPartyRecallLookupRestClient extends Application {
	
	@Override
    public Set<Class<?>> getClasses() {
        Set<Class<?>> classes = new HashSet<Class<?>>();
        classes.add(HelloSessionBean.class);
        return classes;
    }

}

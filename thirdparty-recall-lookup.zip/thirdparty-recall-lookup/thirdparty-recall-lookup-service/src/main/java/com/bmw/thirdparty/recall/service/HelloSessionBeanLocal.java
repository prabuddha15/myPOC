//package com.bmw.thirdparty.recall.service;
//
//import javax.ejb.Local;
//
//@Local
//public interface HelloSessionBeanLocal {
//	String getTime();
//}

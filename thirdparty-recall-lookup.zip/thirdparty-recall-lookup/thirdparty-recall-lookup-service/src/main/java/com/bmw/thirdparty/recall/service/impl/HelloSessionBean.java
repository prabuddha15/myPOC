package com.bmw.thirdparty.recall.service.impl;

import javax.ejb.Stateless;


//import com.bmw.thirdparty.recall.service.HelloSessionBeanLocal;
import com.bmw.thirdparty.recall.service.HelloSessionBeanRemote;


//@Local( HelloSessionBeanLocal.class  )
//@Remote( HelloSessionBeanRemote.class )
@Stateless
public class HelloSessionBean implements HelloSessionBeanRemote  {
	
//	@EJB(name="PlayerDao")
//	PlayerDaoLocal playerDAO;
    
//	@GET
//	@Produces("text/plain")
	@Override
	public String getTime() {
//		List<Player> playerList=playerDAO.getAllPlayers();
//		Player firstPlayer=null;
//		if(playerList!=null && !playerList.isEmpty()){
//			firstPlayer=playerList.get(0);
//		}
//        return firstPlayer.toString();
		return "Hello World";
    }
}
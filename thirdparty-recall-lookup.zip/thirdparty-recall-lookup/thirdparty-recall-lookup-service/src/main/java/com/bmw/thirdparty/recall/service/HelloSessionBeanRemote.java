package com.bmw.thirdparty.recall.service;

import javax.ejb.Remote;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

@Remote
@Path("/timews")
public interface HelloSessionBeanRemote {
	
	@GET
	@Produces("text/plain")
	public String getTime();
}
